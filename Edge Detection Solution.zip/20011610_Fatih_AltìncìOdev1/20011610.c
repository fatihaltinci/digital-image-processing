#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

typedef struct
{
	int genislik;
	int yukseklik;
	int** pixeller;
	int griSeviyesi;
	char pgmVersiyonu[2];
} Resim;

Resim* resimOlusturucu(Resim* foto);
int** yerAyir(int yukseklik, int genislik);
char dosya[50];

void sobelFiltresi(Resim* foto, int tip) {
	Resim* yeniResim = resimOlusturucu(foto);
	Resim* yeniResimX = resimOlusturucu(foto);
	Resim* yeniResimY = resimOlusturucu(foto);
	Resim* yeniResim5 = resimOlusturucu(foto);
	Resim* yeniResim7 = resimOlusturucu(foto);
	
	int sobelFiltresiX[3][3] = { { -1,    0,    1 },
					     { -2,    0,    2 },
					     { -1,    0,    1 } };
					     
	int sobelFiltresiY[3][3] = { {  1,    2,    1 },
					     {  0,    0,    0 },
					     { -1,   -2,   -1 } };
					     
	int sobelFiltresiX5[5][5] = { {  2,    2,    4,    2,    2 },
					      {  1,    1,    2,    1,    1 },
					      {  0,    0,    0,    0,    0 },
						  { -1,   -1,   -2,   -1,   -1 },
						  { -2,   -2,   -4,   -2,   -2 }, };
					     
	int sobelFiltresiY5[5][5] = { {  2,    1,    0,   -1,   -2 },
					      {  2,    1,    0,   -1,   -2 },
					      {  4,    2,    0,   -2,   -4 },
						  {  2,    1,    0,   -1,   -2 },
						  {  2,    1,    0,   -1,   -2 }, };

	int i, j;
	for (i = 1; i < foto->yukseklik - 1; i++)
	{
		for (j = 1; j < foto->genislik - 1; j++)
		{
			yeniResimX->pixeller[i][j] = kernel3x3(sobelFiltresiX, foto, i, j, 0);
			yeniResimY->pixeller[i][j] = kernel3x3(sobelFiltresiY, foto, i, j, 0);
			yeniResim->pixeller[i][j] = round(sqrt(pow(yeniResimX->pixeller[i][j], 2) + pow(yeniResimY->pixeller[i][j], 2)));
		}
	}
	
	for (i = 2; i < foto->yukseklik - 2; i++)
	{
		for (j = 2; j < foto->genislik - 2; j++)
		{
			int x,y;
			x = kernel5x5(sobelFiltresiX5, foto, i, j, 0);
			y = kernel5x5(sobelFiltresiY5, foto, i, j, 0);
			yeniResim5->pixeller[i][j] = round(sqrt(pow(x, 2) + pow(y, 2)));
			yeniResim7->pixeller[i][j] = round(sqrt(pow(x, 2) + pow(y, 2)));
		}
	}
	
	normalizasyon(yeniResim);
	normalizasyon(yeniResimX);
	normalizasyon(yeniResimY);
	normalizasyon(yeniResim5);
	normalizasyon(yeniResim7);
	
	if(tip==0)
	{
		dosyayaYaz("sobel_x.pgm", yeniResimX);
		dosyayaYaz("sobel_y.pgm", yeniResimY);
		dosyayaYaz("sobel_final.pgm", yeniResim);
		dosyayaYaz("sobel_5x5.pgm", yeniResim5);
		dosyayaYaz("sobel_7x7.pgm", yeniResim7);			
	}
	else if(tip==1)
	{
		dosyayaYaz("gauss_3x3s1_sobel.pgm", yeniResim);	
	}
	else if(tip==2)
	{
		dosyayaYaz("gauss_3x3s2_sobel.pgm", yeniResim);	
	}
	else if(tip==3)
	{
		dosyayaYaz("gauss_3x3s4_sobel.pgm", yeniResim);	
	}
	else if(tip==4)
	{
		dosyayaYaz("gauss_5x5s1_sobel.pgm", yeniResim);	
	}
	else if(tip==5)
	{
		dosyayaYaz("gauss_5x5s2_sobel.pgm", yeniResim);	
	}
	else if(tip==6)
	{
		dosyayaYaz("gauss_5x5s4_sobel.pgm", yeniResim);	
	}
	else if(tip==7)
	{
		dosyayaYaz("gauss_7x7s1_sobel.pgm", yeniResim);	
	}
	else if(tip==8)
	{
		dosyayaYaz("gauss_7x7s2_sobel.pgm", yeniResim);	
	}
	else if(tip==9)
	{
		dosyayaYaz("gauss_7x7s4_sobel.pgm", yeniResim);	
	}
	
	return;
}

void gaussFiltresi(Resim* foto) {
	Resim* yeniResim3x3s1 = resimOlusturucu(foto);
	Resim* yeniResim3x3s2 = resimOlusturucu(foto);
	Resim* yeniResim3x3s4 = resimOlusturucu(foto);
	
	Resim* yeniResim5x5s1 = resimOlusturucu(foto);
	Resim* yeniResim5x5s2 = resimOlusturucu(foto);
	Resim* yeniResim5x5s4 = resimOlusturucu(foto);
	
	Resim* yeniResim7x7s1 = resimOlusturucu(foto);
	Resim* yeniResim7x7s2 = resimOlusturucu(foto);
	Resim* yeniResim7x7s4 = resimOlusturucu(foto);

	float gauss3x3s1[3][3] = { {  0.075,    0.123,    0.075 },
						       {  0.123,    0.204,    0.123 },
						       {  0.075,    0.123,    0.075 } };

	float gauss3x3s2[3][3] = { {  0.101,    0.115,    0.101 },
						  	   {  0.115,    0.130,    0.115 },
						       {  0.101,    0.115,    0.101 } };
					
	float gauss3x3s4[3][3] = { {  0.108,    0.112,    0.108 },
						  	   {  0.112,    0.115,    0.112 },
						       {  0.108,    0.112,    0.108 } };
						     
	float gauss5x5s1[5][5] = { {  0.003,    0.013,    0.021,    0.013,    0.003 },
						  	   {  0.013,    0.059,    0.098,    0.059,    0.013 },
						  	   {  0.021,    0.098,    0.162,    0.098,    0.021 },
						  	   {  0.013,    0.059,    0.098,    0.059,    0.013 },
						  	   {  0.003,    0.013,    0.021,    0.013,    0.003 } };
						  	   
	float gauss5x5s2[5][5] = { {  0.023,    0.033,    0.038,    0.033,    0.023 },
						  	   {  0.033,    0.049,    0.055,    0.049,    0.033 },
						  	   {  0.038,    0.055,    0.063,    0.055,    0.038 },
						  	   {  0.033,    0.049,    0.055,    0.049,    0.033 },
						  	   {  0.023,    0.033,    0.038,    0.033,    0.023 } };
						  	   
	float gauss5x5s4[5][5] = { {  0.035,    0.038,    0.039,    0.038,    0.035 },
						  	   {  0.038,    0.042,    0.043,    0.042,    0.038 },
						  	   {  0.039,    0.043,    0.045,    0.043,    0.039 },
						  	   {  0.038,    0.042,    0.043,    0.042,    0.038 },
						  	   {  0.035,    0.038,    0.039,    0.038,    0.035 } };
						  	   
	float gauss7x7s1[7][7] = { {  0.0001,    0.000,    0.001,    0.001,    0.001,    0.000,    0.0001 },
						  	   {  0.000,    0.002,    0.013,    0.021,    0.013,    0.002,    0.000 },
						  	   {  0.001,    0.013,    0.058,    0.096,    0.058,    0.013,    0.001 },
						  	   {  0.001,    0.021,    0.096,    0.159,    0.096,    0.021,    0.001 },
						  	   {  0.001,    0.013,    0.058,    0.096,    0.058,    0.013,    0.001 },
							   {  0.000,    0.002,    0.013,    0.021,    0.013,    0.002,    0.000 },
							   {  0.0001,    0.000,    0.001,    0.001,    0.001,    0.000,    0.0001 } };
							   
	float gauss7x7s2[7][7] = { {  0.004,    0.009,    0.013,    0.015,    0.013,    0.009,    0.004 },
						  	   {  0.009,    0.017,    0.025,    0.028,    0.025,    0.017,    0.009 },
						  	   {  0.013,    0.025,    0.036,    0.041,    0.036,    0.025,    0.013 },
						  	   {  0.015,    0.028,    0.041,    0.046,    0.041,    0.028,    0.015 },
						  	   {  0.013,    0.025,    0.036,    0.041,    0.036,    0.025,    0.013 },
							   {  0.009,    0.017,    0.025,    0.028,    0.025,    0.017,    0.009 },
							   {  0.004,    0.009,    0.013,    0.015,    0.013,    0.009,    0.004 } };
							   
	float gauss7x7s4[7][7] = { {  0.014,    0.017,    0.019,    0.019,    0.019,    0.017,    0.014 },
						  	   {  0.017,    0.020,    0.022,    0.022,    0.022,    0.020,    0.017 },
						  	   {  0.019,    0.022,    0.024,    0.025,    0.024,    0.022,    0.019 },
						  	   {  0.019,    0.022,    0.025,    0.025,    0.025,    0.022,    0.019 },
						  	   {  0.019,    0.022,    0.024,    0.025,    0.024,    0.022,    0.019 },
							   {  0.017,    0.020,    0.022,    0.022,    0.022,    0.020,    0.017 },
							   {  0.014,    0.017,    0.019,    0.019,    0.019,    0.017,    0.014 } };
						    
	int i, j;
	for (i = 1; i < foto->yukseklik - 1; i++)
	{
		for (j = 1; j < foto->genislik - 1; j++)
		{
			yeniResim3x3s1->pixeller[i][j] = kernel3x3(gauss3x3s1, foto, i, j, 1);
			yeniResim3x3s2->pixeller[i][j] = kernel3x3(gauss3x3s2, foto, i, j, 1);
			yeniResim3x3s4->pixeller[i][j] = kernel3x3(gauss3x3s4, foto, i, j, 1);
		}
	}
	
	for (i = 2; i < foto->yukseklik - 2; i++)
	{
		for (j = 2; j < foto->genislik - 2; j++)
		{
			yeniResim5x5s1->pixeller[i][j] = kernel5x5(gauss5x5s1, foto, i, j, 1);
			yeniResim5x5s2->pixeller[i][j] = kernel5x5(gauss5x5s2, foto, i, j, 1);
			yeniResim5x5s4->pixeller[i][j] = kernel5x5(gauss5x5s4, foto, i, j, 1);
		}
	}
	
	for (i = 3; i < foto->yukseklik - 3; i++)
	{
		for (j = 3; j < foto->genislik - 3; j++)
		{
			yeniResim7x7s1->pixeller[i][j] = kernel7x7(gauss7x7s1, foto, i, j, 1);	
			yeniResim7x7s2->pixeller[i][j] = kernel7x7(gauss7x7s2, foto, i, j, 1);
			yeniResim7x7s4->pixeller[i][j] = kernel7x7(gauss7x7s4, foto, i, j, 1);
		}
	}
	
	normalizasyon(yeniResim3x3s1);
	normalizasyon(yeniResim3x3s2);
	normalizasyon(yeniResim3x3s4);
	
	normalizasyon(yeniResim5x5s1);
	normalizasyon(yeniResim5x5s2);
	normalizasyon(yeniResim5x5s4);
	
	normalizasyon(yeniResim7x7s1);
	normalizasyon(yeniResim7x7s2);
	normalizasyon(yeniResim7x7s4);
	
	laplacian(yeniResim3x3s1,1);
	laplacian(yeniResim3x3s2,2);
	laplacian(yeniResim3x3s4,3);
	
	sobelFiltresi(yeniResim3x3s1,1);
	sobelFiltresi(yeniResim3x3s2,2);
	sobelFiltresi(yeniResim3x3s4,3);
	
	laplacian(yeniResim5x5s1,4);
	laplacian(yeniResim5x5s2,5);
	laplacian(yeniResim5x5s4,6);
	
	sobelFiltresi(yeniResim5x5s1,4);
	sobelFiltresi(yeniResim5x5s2,5);
	sobelFiltresi(yeniResim5x5s4,6);
	
	laplacian(yeniResim7x7s1,7);
	laplacian(yeniResim7x7s2,8);
	laplacian(yeniResim7x7s4,9);
	
	sobelFiltresi(yeniResim7x7s1,7);
	sobelFiltresi(yeniResim7x7s2,8);
	sobelFiltresi(yeniResim7x7s4,9);
	
	dosyayaYaz("gauss_3x3s1.pgm", yeniResim3x3s1);
	dosyayaYaz("gauss_3x3s2.pgm", yeniResim3x3s2);
	dosyayaYaz("gauss_3x3s4.pgm", yeniResim3x3s4);
	
	dosyayaYaz("gauss_5x5s1.pgm", yeniResim5x5s1);
	dosyayaYaz("gauss_5x5s2.pgm", yeniResim5x5s2);
	dosyayaYaz("gauss_5x5s4.pgm", yeniResim5x5s4);
	
	dosyayaYaz("gauss_7x7s1.pgm", yeniResim7x7s1);
	dosyayaYaz("gauss_7x7s2.pgm", yeniResim7x7s2);
	dosyayaYaz("gauss_7x7s4.pgm", yeniResim7x7s4);	
	
	return;
}



void laplacian(Resim* foto, int tip) {
	Resim* yeniResim1 = resimOlusturucu(foto);
	Resim* yeniResim2 = resimOlusturucu(foto);
	
	int Laplacian1[3][3] = { {  0,   -1,    0 },
					         { -1,    4,   -1 },
					         {  0,   -1,    0 } };
					         
	int Laplacian2[3][3] = { { -1,   -1,   -1 },
					 	     { -1,    8,   -1 },
					         { -1,   -1,   -1 } };

	int i, j;
	for (i = 1; i < foto->yukseklik - 1; i++)
	{
		for (j = 1; j < foto->genislik - 1; j++)
		{
			yeniResim1->pixeller[i][j] = kernel3x3(Laplacian1, foto, i, j, 0);
			yeniResim2->pixeller[i][j] = kernel3x3(Laplacian2, foto, i, j, 0);
		}
	}
	
	normalizasyon(yeniResim1);
	normalizasyon(yeniResim2);
	
	if(tip==0)
	{
		dosyayaYaz("laplacian1.pgm", yeniResim1);
		dosyayaYaz("laplacian2.pgm", yeniResim2);
	}
	else if(tip==1)
	{
		dosyayaYaz("gauss_3x3s1_laplacian_1.pgm", yeniResim1);	
		dosyayaYaz("gauss_3x3s1_laplacian_2.pgm", yeniResim2);	
	}
	else if(tip==2)
	{
		dosyayaYaz("gauss_3x3s2_laplacian_1.pgm", yeniResim1);	
		dosyayaYaz("gauss_3x3s2_laplacian_2.pgm", yeniResim2);	
	}
	else if(tip==3)
	{
		dosyayaYaz("gauss_3x3s4_laplacian_1.pgm", yeniResim1);	
		dosyayaYaz("gauss_3x3s4_laplacian_2.pgm", yeniResim2);	
	}
	else if(tip==4)
	{
		dosyayaYaz("gauss_5x5s1_laplacian_1.pgm", yeniResim1);	
		dosyayaYaz("gauss_5x5s1_laplacian_2.pgm", yeniResim2);	
	}
	else if(tip==5)
	{
		dosyayaYaz("gauss_5x5s2_laplacian_1.pgm", yeniResim1);	
		dosyayaYaz("gauss_5x5s2_laplacian_2.pgm", yeniResim2);	
	}
	else if(tip==6)
	{
		dosyayaYaz("gauss_5x5s4_laplacian_1.pgm", yeniResim1);	
		dosyayaYaz("gauss_5x5s4_laplacian_2.pgm", yeniResim2);	
	}
	else if(tip==7)
	{
		dosyayaYaz("gauss_7x7s1_laplacian_1.pgm", yeniResim1);	
		dosyayaYaz("gauss_7x7s1_laplacian_2.pgm", yeniResim2);	
	}
	else if(tip==8)
	{
		dosyayaYaz("gauss_7x7s2_laplacian_1.pgm", yeniResim1);	
		dosyayaYaz("gauss_7x7s2_laplacian_2.pgm", yeniResim2);	
	}
	else if(tip==9)
	{
		dosyayaYaz("gauss_7x7s4_laplacian_1.pgm", yeniResim1);	
		dosyayaYaz("gauss_7x7s4_laplacian_2.pgm", yeniResim2);	
	}
	
	return;
}

Resim* resimOlusturucu(Resim* foto) {
	Resim* yeniResim = (Resim*)malloc(sizeof(Resim));
	strcpy(yeniResim->pgmVersiyonu, foto->pgmVersiyonu);
	yeniResim->yukseklik = foto->yukseklik;
	yeniResim->genislik = foto->genislik;
	yeniResim->griSeviyesi = foto->griSeviyesi;
	yeniResim->pixeller = yerAyir(yeniResim->yukseklik, yeniResim->genislik);
	return yeniResim;
}

void normalizasyon(Resim* foto) {
	int maxDeger = foto->pixeller[0][0];
	int minDeger = foto->pixeller[0][0];
	int i,j;

	for (i = 0; i < foto->yukseklik; i++)
	{
		for (j = 0; j < foto->genislik; j++)
		{
			if (foto->pixeller[i][j] > maxDeger)
			{
				maxDeger = foto->pixeller[i][j];
			}

			if (foto->pixeller[i][j] < minDeger)
			{
				minDeger = foto->pixeller[i][j];
			}
		}
	}

	int fark = maxDeger - minDeger, yeniDeger;
	for (i = 0; i < foto->yukseklik; i++)
	{
		for (j = 0; j < foto->genislik; j++)
		{
			yeniDeger = round(((foto->pixeller[i][j]) - minDeger) * 255 / fark);
			foto->pixeller[i][j] = yeniDeger;
		}
	}
}

int kernel3x3(int mask[3][3], Resim* foto, int row, int col, int tip) {
	float toplam = 0;
	int i, j;
	for (i = row - 1; i <= row + 1; i++)
	{
		for (j = col - 1; j <= col + 1; j++)
		{
			if(tip==0)
				toplam += (float)(foto->pixeller[i][j]) * (float)((float)mask[i - row + 1][j - col + 1]);
			else if(tip==1)
				toplam += (float)(foto->pixeller[i][j]) * (float)((float)mask[i - row + 1][j - col + 1]/(float)mask[0][0]);
		}
	}
	return (int)toplam;
}

int kernel5x5(int mask[5][5], Resim* foto, int row, int col, int tip) {
	float toplam = 0;
	int i, j;
	for (i = row - 2; i <= row + 2; i++)
	{
		for (j = col - 2; j <= col + 2; j++)
		{
			if(tip==0)
				toplam += (float)(foto->pixeller[i][j]) * (float)((float)mask[i - row + 2][j - col + 2]);
			else if(tip==1)
				toplam += (float)(foto->pixeller[i][j]) * (float)((float)mask[i - row + 2][j - col + 2]/(float)mask[0][0]);
		}
	}
	return (int)toplam;
}

int kernel7x7(int mask[7][7], Resim* foto, int row, int col, int tip) {
	float toplam = 0;
	int i, j;
	for (i = row - 3; i <= row + 3; i++)
	{
		for (j = col - 3; j <= col + 3; j++)
		{
			if(tip==0)
				toplam += (float)(foto->pixeller[i][j]) * (float)((float)mask[i - row + 3][j - col + 3]);
			else if(tip==1)
				toplam += (float)(foto->pixeller[i][j]) * (float)((float)mask[i - row + 3][j - col + 3]/(float)mask[0][0]);
		}
	}
	return (int)toplam;
}

Resim* dosyaOku(const char* fileName)
{
	FILE* fotoDosya;
	Resim* foto = (Resim*)malloc(sizeof(Resim));
	char versiyon[3];
	int i, j;
	int lo, hi;
	fotoDosya = fopen(fileName, "rb+");
	if (fotoDosya == NULL) {
		perror("Dosya okunamadi.");
		exit(EXIT_FAILURE);
	}
	fgets(versiyon, sizeof(versiyon), fotoDosya);
	
	strcpy(foto->pgmVersiyonu, versiyon);

	yorumSatirlariniSilme(fotoDosya);
	fscanf(fotoDosya, "%d", &foto->genislik);
	yorumSatirlariniSilme(fotoDosya);
	fscanf(fotoDosya, "%d", &foto->yukseklik);
	yorumSatirlariniSilme(fotoDosya);
	fscanf(fotoDosya, "%d", &foto->griSeviyesi);
	fgetc(fotoDosya);
	
	if (!strcmp(versiyon, "P5")) {
		foto->pixeller = yerAyir(foto->yukseklik, foto->genislik);
		if (foto->griSeviyesi > 255) {
			for (i = 0; i < foto->yukseklik; ++i) {
				for (j = 0; j < foto->genislik; ++j) {
					hi = fgetc(fotoDosya);
					lo = fgetc(fotoDosya);
					foto->pixeller[i][j] = (hi << 8) + lo;
				}
			}
		}
		else {
			for (i = 0; i < foto->yukseklik; ++i) {
				for (j = 0; j < foto->genislik; ++j) {
					lo = fgetc(fotoDosya);
					foto->pixeller[i][j] = lo;
				}
			}
		}
	}
	else if (!strcmp(versiyon, "P2")) {
		foto->pixeller = yerAyir(foto->yukseklik, foto->genislik);
		if (foto->griSeviyesi > 255) {
			for (i = 0; i < foto->yukseklik; ++i) {
				for (j = 0; j < foto->genislik; ++j) {
					fscanf(fotoDosya, "%d", &hi);
					fscanf(fotoDosya, "%d", &lo);
					foto->pixeller[i][j] = (hi << 8) + lo;
				}
			}
		}
		else {
			for (i = 0; i < foto->yukseklik; ++i) {
				for (j = 0; j < foto->genislik; ++j) {
					fscanf(fotoDosya, "%d", &lo);
					foto->pixeller[i][j] = lo;
				}
			}
		}

		fclose(fotoDosya);
	}

	return foto;
}

char* dosyaAdiniAl(char* fileName)
{
	char* dosya = (char*)calloc(strlen(fileName), sizeof(char));
	char* extension;
	if (fileName != NULL) {
		strcpy(dosya, fileName);
		extension = strrchr(dosya, '.');
		if (extension != NULL)
			*extension = '\0';
	}

	return dosya;
}

void matrisiBosalt(int** pixeller, int yukseklik)
{
	int i;
	for (i = 0; i < yukseklik; ++i) {
		free(pixeller[i]);
	}
	free(pixeller);
}

void dosyayaYaz(const char* dosyaAdi, Resim* yeniResim)
{
	FILE* fotoDosya;
	int i, j;
	int hi, lo;
	
	char output[100];
	strcpy(output, dosya);
	strcat(output, "_");
	strcat(output, dosyaAdi);
	

	fotoDosya = fopen(output, "wb");
	if (fotoDosya == NULL) {
		perror("Dosya acilamadi.");
		exit(EXIT_FAILURE);
	}

    if(!strcmp(yeniResim->pgmVersiyonu, "P5"))
        fprintf(fotoDosya, "P5\n");
	else if(!strcmp(yeniResim->pgmVersiyonu, "P2"))
        fprintf(fotoDosya, "P2\n");
	fprintf(fotoDosya, "%d %d\n", yeniResim->genislik, yeniResim->yukseklik);
	fprintf(fotoDosya, "%d\n", yeniResim->griSeviyesi);

	if (yeniResim->griSeviyesi > 255) {
		for (i = 0; i < yeniResim->yukseklik; ++i) {
			for (j = 0; j < yeniResim->genislik; ++j) {
			    hi = (((yeniResim->pixeller[i][j]) & 0x0000FF00) << 8);
				lo = ((yeniResim->pixeller[i][j]) & 0x000000FF);
				if(!strcmp(yeniResim->pgmVersiyonu, "P5"))
				{
					fputc(hi, fotoDosya);
				    fputc(lo, fotoDosya);
				}
				else if(!strcmp(yeniResim->pgmVersiyonu, "P2"))
				{
					fprintf(fotoDosya, "%d ", yeniResim->pixeller[i][j]);
				}
			}
		}
	}
	else {
		for (i = 0; i < yeniResim->yukseklik; ++i) {
			for (j = 0; j < yeniResim->genislik; ++j) {
				lo = ((yeniResim->pixeller[i][j]) & 0x000000FF);
				if(!strcmp(yeniResim->pgmVersiyonu, "P5"))
				{
					fputc(lo, fotoDosya);
				}
				else if(!strcmp(yeniResim->pgmVersiyonu, "P2"))
				{
					fprintf(fotoDosya, "%d ", yeniResim->pixeller[i][j]);
				}
			}
		}
	}

	matrisiBosalt(yeniResim->pixeller, yeniResim->yukseklik);
	free(yeniResim);
	fclose(fotoDosya);
}

int** yerAyir(int yukseklik, int genislik)
{
	int** pixeller = (int**)malloc(yukseklik * sizeof(int*));
	if (!pixeller) {
		printf("Yer ayrilamadi.");
	}
	int i;
	for (i = 0; i < yukseklik; i++)
	{
		pixeller[i] = (int*)malloc(genislik * sizeof(int));
		if (!pixeller[i]) {
			printf("Yer ayrilamadi.");
			return 0;
		}
	}
	return pixeller;
}

void yorumSatirlariniSilme(FILE* fp)
{
	int ch;
	char line[100];
	while ((ch = fgetc(fp)) != EOF && isspace(ch)) {
		;
	}

	if (ch == '#') {
		fgets(line, sizeof(line), fp);
		yorumSatirlariniSilme(fp);
	}
	else {
		fseek(fp, -1, SEEK_CUR);
	}
}



int main() {
	char dosyaAdi[50];
	printf("PGM dosyasinin adini uzantisiyla birlikte giriniz: ");
	scanf("%s", dosyaAdi);
	Resim* foto = dosyaOku(dosyaAdi);
	
	printf("Fotograf Bilgileri\n");
	printf("PGM Versiyonu: %s\n", foto->pgmVersiyonu);
	printf("Resmin Genisligi: %d\n", foto->genislik);
	printf("Resmin Yuksekligi: %d\n", foto->yukseklik);
	printf("Resmin Gri Seviyesi: %d\n", foto->griSeviyesi);
	
	strcpy(dosya, dosyaAdiniAl(dosyaAdi));
	
	gaussFiltresi(foto);
	sobelFiltresi(foto, 0);
	
	return 0;
}
